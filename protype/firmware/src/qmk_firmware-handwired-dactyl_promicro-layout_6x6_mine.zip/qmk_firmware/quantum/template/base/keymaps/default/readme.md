# The default keymap for %KEYBOARD%
